export class User{
    userId: number;
    title: string;
}
